' PLiMS Windows Shortcut Generator
Set oWS = WScript.CreateObject("WScript.Shell")
targetDir = WScript.Arguments(0)

' 1. Desktop Shortcut
sDesktop = oWS.SpecialFolders("Desktop") & "\PLiMS 4.1.1 PK Edition.lnk"
Set oLink = oWS.CreateShortcut(sDesktop)
oLink.TargetPath = targetDir & "\PLiMS.exe"
oLink.WorkingDirectory = targetDir
oLink.IconLocation = targetDir & "\plims.ico,0"
oLink.Description = "Pakistan Library Management System (PLiMS 4.1.1 PK Edition)"
oLink.Save

' 2. Start Menu Shortcut
sPrograms = oWS.SpecialFolders("Programs") & "\PLiMS 4.1.1"
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FolderExists(sPrograms) Then
    fso.CreateFolder(sPrograms)
End If
sStartLink = sPrograms & "\PLiMS 4.1.1 PK Edition.lnk"
Set oStartLink = oWS.CreateShortcut(sStartLink)
oStartLink.TargetPath = targetDir & "\PLiMS.exe"
oStartLink.WorkingDirectory = targetDir
oStartLink.IconLocation = targetDir & "\plims.ico,0"
oStartLink.Description = "Pakistan Library Management System (PLiMS 4.1.1 PK Edition)"
oStartLink.Save
