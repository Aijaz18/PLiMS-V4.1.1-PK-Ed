' PLiMS Windows Shortcut Generator
Set oWS = WScript.CreateObject("WScript.Shell")
targetDir = WScript.Arguments(0)

' 1. Desktop Shortcut
sDesktop = oWS.SpecialFolders("Desktop") & "\PLiMS 4.1.1 PK Edition.lnk"
Set oLink = oWS.CreateShortcut(sDesktop)
oLink.TargetPath = targetDir & "\PLiMS-Launch.bat"
oLink.WorkingDirectory = targetDir
oLink.Description = "Pakistan Library Management System (PLiMS 4.1.1)"
oLink.Save

' 2. Start Menu Shortcut
sPrograms = oWS.SpecialFolders("Programs") & "\PLiMS 4.1.1"
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FolderExists(sPrograms) Then
    fso.CreateFolder(sPrograms)
End If
sStartLink = sPrograms & "\PLiMS 4.1.1.lnk"
Set oStartLink = oWS.CreateShortcut(sStartLink)
oStartLink.TargetPath = targetDir & "\PLiMS-Launch.bat"
oStartLink.WorkingDirectory = targetDir
oStartLink.Description = "Pakistan Library Management System (PLiMS 4.1.1)"
oStartLink.Save
