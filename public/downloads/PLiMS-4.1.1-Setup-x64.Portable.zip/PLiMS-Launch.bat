@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - Desktop Engine
echo ===============================================================================
echo   PAKISTAN LIBRARY MANAGEMENT SYSTEM (PLiMS) V4.1.1 PK EDITION
echo   Department of Libraries, Government of Pakistan
echo   Official Windows Desktop Engine (Winsock TcpListener - Zero Admin Required)
echo ===============================================================================
echo.
cd /d "%~dp0"

echo [*] Starting PLiMS local offline server and opening desktop window...
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1" -LaunchBrowser

echo.
echo ===============================================================================
echo   [OK] PLiMS DESKTOP ENGINE IS LAUNCHING!
echo   Your PLiMS 4.1.1 Desktop window will open automatically in 1-2 seconds.
echo   If the window does not appear automatically, open: http://127.0.0.1:3000
echo ===============================================================================
timeout /t 4 >nul
exit /b 0
