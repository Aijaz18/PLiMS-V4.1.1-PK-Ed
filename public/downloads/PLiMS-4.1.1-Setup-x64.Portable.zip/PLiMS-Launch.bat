@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - Desktop Engine
echo ===============================================================================
echo   PAKISTAN LIBRARY MANAGEMENT SYSTEM (PLiMS) V4.1.1 PK EDITION
echo   Department of Libraries, Government of Pakistan
echo   Official Windows Desktop Engine
echo ===============================================================================
echo.
cd /d "%~dp0"

echo [*] Initializing PLiMS local offline server on port 3000...
start /b "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1" -Port 3000

echo [*] Waiting for local engine socket...
ping 127.0.0.1 -n 2 >nul

echo [*] Launching PLiMS V4.1.1 in default web browser...
start http://127.0.0.1:3000

echo.
echo ===============================================================================
echo   [OK] PLiMS DESKTOP ENGINE IS ACTIVE AND READY!
echo   All Modules: OPAC, Cataloguing, Circulation, AI Librarian Bot, Reports, Barcodes
echo ===============================================================================
echo [i] Keep this console window open while working in PLiMS.
echo [i] To stop the system, close this window or press Ctrl+C.
echo.
pause
