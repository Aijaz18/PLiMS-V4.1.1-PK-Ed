@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - Official Desktop Engine
cd /d "%~dp0"

echo ===============================================================================
echo   PAKISTAN LIBRARY MANAGEMENT SYSTEM (PLiMS) V4.1.1 PK EDITION
echo   Department of Libraries, Government of Pakistan
echo   Official Windows Desktop Suite (All Modules Enabled)
echo ===============================================================================
echo.

echo [*] Starting PLiMS local offline engine on http://127.0.0.1:3000 ...
start /b "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1" -Port 3000 >nul 2>&1

echo [*] Verifying local engine socket...
ping 127.0.0.1 -n 3 >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $c = New-Object System.Net.Sockets.TcpClient('127.0.0.1', 3000); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if !errorlevel! equ 0 (
    echo [OK] Local HTTP Engine is active on http://127.0.0.1:3000
    echo [*] Opening PLiMS V4.1.1 PK Edition...
    start "" "http://127.0.0.1:3000"
) else (
    echo [i] Opening PLiMS V4.1.1 in Direct Standalone Offline Mode...
    start "" "%~dp0PLiMS-Application.html"
)

echo.
echo ===============================================================================
echo   [OK] PLiMS V4.1.1 DESKTOP APPLICATION IS RUNNING!
echo   Modules Active: OPAC, Cataloguing, Circulation, AI Librarian, Reports, Barcodes
echo ===============================================================================
echo [i] You can minimize this window while working in PLiMS.
timeout /t 5 >nul
