-- PLiMS V4.1.1 Offline Database Bootstrap Schema
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT
);

INSERT INTO metadata (key, value) VALUES 
('system_name', 'PLiMS Pakistan Library Management System'),
('version', '4.1.1'),
('release_channel', 'official_desktop_r2');

CREATE TABLE IF NOT EXISTS offline_transactions (
    id TEXT PRIMARY KEY,
    member_code TEXT NOT NULL,
    copy_barcode TEXT NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    status TEXT DEFAULT 'ISSUED',
    synced_to_cloud INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS offline_catalog (
    id TEXT PRIMARY KEY,
    isbn TEXT,
    title TEXT NOT NULL,
    authors TEXT,
    call_number TEXT,
    ddc_number TEXT,
    total_copies INTEGER DEFAULT 1,
    available_copies INTEGER DEFAULT 1
);
