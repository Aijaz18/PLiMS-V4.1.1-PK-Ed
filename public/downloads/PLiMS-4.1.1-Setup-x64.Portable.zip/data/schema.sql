-- PLiMS V4.1.1 Offline Database Bootstrap Schema
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT
);

INSERT INTO metadata (key, value) VALUES 
('system_name', 'PLiMS Pakistan Library Management System'),
('version', '4.1.1'),
('release_channel', 'official_desktop');
