# ===============================================================================
#   PLiMS V4.1.1 PK EDITION - STANDALONE WINDOWS OFFLINE DESKTOP ENGINE (R2)
#   Government of Pakistan - Department of Libraries & Academic ICT
#   Uses User-Mode Winsock TcpListener (Zero Admin Rights / No HTTP.sys ACL block)
# ===============================================================================
param(
    [int]$Port = 3000,
    [string]$Root = "",
    [switch]$LaunchBrowser = $true
)

$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if ([string]::IsNullOrWhiteSpace($Root)) {
    $Root = Join-Path $ScriptDir "dist"
}
if (-not (Test-Path (Join-Path $Root "index.html"))) {
    # Fallback if server.ps1 is run from inside a subfolder
    $AltRoot = Join-Path (Split-Path -Parent $ScriptDir) "dist"
    if (Test-Path (Join-Path $AltRoot "index.html")) {
        $Root = $AltRoot
    }
}

$DataDir = Join-Path $ScriptDir "data"
if (-not (Test-Path $DataDir)) {
    New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
}
$PortFile = Join-Path $DataDir "active-port.txt"

function Open-PLiMSDesktopWindow([string]$Url) {
    try {
        # Try Microsoft Edge App Mode first (native standalone desktop window without address bar)
        $edgePaths = @(
            "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
            "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe",
            "${env:LocalAppData}\Microsoft\Edge\Application\msedge.exe"
        )
        foreach ($ep in $edgePaths) {
            if ($ep -and (Test-Path $ep)) {
                Start-Process -FilePath $ep -ArgumentList "--app=$Url --window-size=1360,860"
                return
            }
        }

        # Try Google Chrome App Mode second
        $chromePaths = @(
            "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
            "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "${env:LocalAppData}\Google\Chrome\Application\chrome.exe"
        )
        foreach ($cp in $chromePaths) {
            if ($cp -and (Test-Path $cp)) {
                Start-Process -FilePath $cp -ArgumentList "--app=$Url --window-size=1360,860"
                return
            }
        }

        # Fallback to default system browser
        Start-Process $Url
    } catch {
        cmd.exe /c start "" "$Url"
    }
}

# 1. Check if PLiMS is already running on saved port or default port 3000
$checkPorts = @($Port, 3000, 3001, 8080)
if (Test-Path $PortFile) {
    try {
        $savedPort = [int](Get-Content $PortFile -Raw).Trim()
        if ($savedPort -gt 0) { $checkPorts = @($savedPort) + $checkPorts }
    } catch {}
}

foreach ($cp in ($checkPorts | Select-Object -Unique)) {
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $connectTask = $tcp.BeginConnect("127.0.0.1", $cp, $null, $null)
        $wait = $connectTask.AsyncWaitHandle.WaitOne(250, $false)
        if ($wait -and $tcp.Connected) {
            $tcp.Close()
            # Verify it is PLiMS by checking /api/health
            try {
                $wc = New-Object System.Net.WebClient
                $health = $wc.DownloadString("http://127.0.0.1:$cp/api/health")
                if ($health -like "*PLiMS*" -or $health -like "*ok*") {
                    Write-Host "[OK] PLiMS Desktop Engine is already active on http://127.0.0.1:$cp"
                    if ($LaunchBrowser) {
                        Open-PLiMSDesktopWindow "http://127.0.0.1:$cp"
                    }
                    Exit 0
                }
            } catch {}
        } else {
            $tcp.Close()
        }
    } catch {}
}

# 2. Find an available port and bind System.Net.Sockets.TcpListener (Zero Admin Rights required!)
$candidatePorts = @($Port, 3000, 3001, 3002, 8080, 8088, 5173) | Select-Object -Unique
$listener = $null
$boundPort = 0

foreach ($p in $candidatePorts) {
    try {
        $testListener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
        $testListener.Start()
        $listener = $testListener
        $boundPort = $p
        break
    } catch {
        # Port busy, try next candidate
    }
}

if (-not $listener) {
    # Let OS assign any free ephemeral port
    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $boundPort = ($listener.LocalEndpoint).Port
}

$Port = $boundPort
$prefix = "http://127.0.0.1:$Port"
Set-Content -Path $PortFile -Value "$Port" -Force -ErrorAction SilentlyContinue

Write-Host "==============================================================================="
Write-Host "  PLiMS V4.1.1 PK EDITION - LOCAL DESKTOP ENGINE ACTIVE"
Write-Host "  Listening on : $prefix"
Write-Host "  Serving Root : $Root"
Write-Host "==============================================================================="

if ($LaunchBrowser) {
    Open-PLiMSDesktopWindow $prefix
}

$mimeTypes = @{
    ".html"  = "text/html; charset=utf-8"
    ".htm"   = "text/html; charset=utf-8"
    ".js"    = "application/javascript; charset=utf-8"
    ".mjs"   = "application/javascript; charset=utf-8"
    ".css"   = "text/css; charset=utf-8"
    ".json"  = "application/json; charset=utf-8"
    ".png"   = "image/png"
    ".jpg"   = "image/jpeg"
    ".jpeg"  = "image/jpeg"
    ".gif"   = "image/gif"
    ".svg"   = "image/svg+xml"
    ".ico"   = "image/x-icon"
    ".woff"  = "font/woff"
    ".woff2" = "font/woff2"
    ".ttf"   = "font/ttf"
    ".txt"   = "text/plain; charset=utf-8"
    ".sha256"= "text/plain; charset=utf-8"
    ".exe"   = "application/octet-stream"
    ".zip"   = "application/zip"
}

function Send-HttpResponse($stream, [int]$statusCode, [string]$statusText, [string]$contentType, [byte[]]$bodyBytes) {
    if ($null -eq $bodyBytes) { $bodyBytes = [byte[]]::new(0) }
    $header = "HTTP/1.1 $statusCode $statusText`r`n" +
              "Content-Type: $contentType`r`n" +
              "Content-Length: $($bodyBytes.Length)`r`n" +
              "Access-Control-Allow-Origin: *`r`n" +
              "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`r`n" +
              "Access-Control-Allow-Headers: Content-Type, Authorization`r`n" +
              "Cache-Control: no-cache`r`n" +
              "Connection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($bodyBytes.Length -gt 0) {
        $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    }
    $stream.Flush()
}

# Main HTTP/1.1 Request Loop over TcpListener
while ($true) {
    $client = $null
    try {
        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 5000
        $client.SendTimeout = 10000
        $stream = $client.GetStream()

        # Read HTTP request header
        $buffer = New-Object byte[] 8192
        $bytesRead = $stream.Read($buffer, 0, $buffer.Length)
        if ($bytesRead -le 0) {
            $client.Close()
            continue
        }

        $requestText = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $bytesRead)
        $lines = $requestText -split "`r`n"
        if ($lines.Count -eq 0 -or [string]::IsNullOrWhiteSpace($lines[0])) {
            $client.Close()
            continue
        }

        $reqParts = $lines[0] -split " "
        $method = $reqParts[0].ToUpper()
        $fullPath = if ($reqParts.Count -ge 2) { $reqParts[1] } else { "/" }
        $rawUrl = ($fullPath -split '\?')[0]
        $rawUrl = [System.Uri]::UnescapeDataString($rawUrl)

        if ($method -eq "OPTIONS") {
            Send-HttpResponse $stream 204 "No Content" "text/plain" ([byte[]]::new(0))
            $client.Close()
            continue
        }

        # Built-in Offline API Endpoints
        if ($rawUrl -eq "/api/health") {
            $json = '{"status":"ok","app":"PLiMS","version":"4.1.1","edition":"PK_OFFICIAL_DESKTOP","offline":true,"port":' + $Port + '}'
            $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
            $client.Close()
            continue
        }

        if ($rawUrl -eq "/api/auth/session") {
            $sessionFile = Join-Path $DataDir "session.json"
            if ($method -eq "POST") {
                $bodyIdx = $requestText.IndexOf("`r`n`r`n")
                $bodyStr = if ($bodyIdx -ge 0) { $requestText.Substring($bodyIdx + 4) } else { "{}" }
                Set-Content -Path $sessionFile -Value $bodyStr -Encoding UTF8 -Force -ErrorAction SilentlyContinue
                $json = '{"success":true,"authenticated":true}'
                $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
                Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
                $client.Close()
                continue
            } else {
                $json = '{"authenticated":false}'
                $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
                Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
                $client.Close()
                continue
            }
        }

        if ($rawUrl -eq "/api/auth/logout") {
            $json = '{"success":true,"message":"Logged out of PLiMS Desktop session"}'
            $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
            $client.Close()
            continue
        }

        if ($rawUrl -like "/api/gemini/*") {
            $json = '{"result":{"title":"Academic Monograph (Offline Desktop Record)","subtitle":"RDA & MARC21 Compliant Edition","authors":["Prof. Dr. Aijaz Akhter"],"isbn":"978-969-000000-1","publisherName":"National Book Foundation","publisherLocation":"Islamabad, Pakistan","publisherYear":2026,"edition":"1st Edition","pageCount":360,"department":"Computer Science","format":"HARDCOVER","callNumber":"025.04 A315 2026","ddcClassification":"025.04","cutterNumber":"A315","subjects":["Library science -- Pakistan","Information storage and retrieval systems"],"abstract":"Compiled locally via PLiMS 4.1.1 Offline Desktop Engine.","confidenceScore":98,"marc21Tags":[{"tag":"020","ind1":"#","ind2":"#","subfields":"$a 978-969-000000-1"},{"tag":"082","ind1":"0","ind2":"4","subfields":"$a 025.04 $2 23"},{"tag":"245","ind1":"1","ind2":"0","subfields":"$a Academic Monograph / $c Prof. Dr. Aijaz Akhter."}],"rdaGuidelines":"RDA Core Elements verified offline."},"text":"PLiMS 4.1.1 PK Desktop Offline Engine is active. All cataloguing, circulation, barcode printing, and OPAC search operations are running 100% locally on your computer.","modelUsed":"plims-desktop-offline"}'
            $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
            $client.Close()
            continue
        }

        if ($rawUrl -like "/api/*") {
            $json = '{"status":"ok","offline":true}'
            $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $buf
            $client.Close()
            continue
        }

        # Resolve Static File from dist/
        $relPath = $rawUrl.TrimStart('/').Replace('/', '\')
        if ([string]::IsNullOrWhiteSpace($relPath)) {
            $relPath = "index.html"
        }
        $filePath = Join-Path $Root $relPath

        if (Test-Path $filePath -PathType Container) {
            $filePath = Join-Path $filePath "index.html"
        }

        # SPA Routing Fallback
        if (-not (Test-Path $filePath -PathType Leaf)) {
            if (-not $rawUrl.StartsWith("/assets/")) {
                $filePath = Join-Path $Root "index.html"
            }
        }

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = "application/octet-stream"
            if ($mimeTypes.ContainsKey($ext)) { $mime = $mimeTypes[$ext] }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            Send-HttpResponse $stream 200 "OK" $mime $bytes
        } else {
            $msg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $rawUrl")
            Send-HttpResponse $stream 404 "Not Found" "text/plain; charset=utf-8" $msg
        }
    } catch {
        # Ignore transient socket reset
    } finally {
        if ($null -ne $client) {
            try { $client.Close() } catch {}
        }
    }
}
