# ===============================================================================
#   PLiMS V4.1.1 PK EDITION - UNPRIVILEGED WINDOWS OFFLINE TCP HTTP ENGINE
#   Government of Pakistan - Department of Libraries & Academic ICT
#   Uses System.Net.Sockets.TcpListener (Zero Admin Rights or URL ACLs Required!)
# ===============================================================================
param(
    [int]$Port = 3000,
    [string]$Root = (Join-Path $PSScriptRoot "dist")
)

$ErrorActionPreference = "Continue"

# Check if port is already serving PLiMS
try {
    $check = New-Object System.Net.Sockets.TcpClient
    $check.Connect("127.0.0.1", $Port)
    $check.Close()
    Write-Host "[OK] PLiMS Desktop Engine is already active on http://127.0.0.1:$Port"
    Exit 0
} catch {
    # Port is available
}

$endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Loopback, $Port)
$listener = New-Object System.Net.Sockets.TcpListener($endpoint)

try {
    $listener.Start()
} catch {
    $Port = 3080
    $endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Loopback, $Port)
    $listener = New-Object System.Net.Sockets.TcpListener($endpoint)
    $listener.Start()
}

Write-Host "==============================================================================="
Write-Host "  PLiMS V4.1.1 PK EDITION - LOCAL DESKTOP ENGINE ACTIVE"
Write-Host "  URL:     http://127.0.0.1:$Port"
Write-Host "  Root:    $Root"
Write-Host "==============================================================================="

$mimeTypes = @{
    ".html"  = "text/html; charset=utf-8"
    ".htm"   = "text/html; charset=utf-8"
    ".js"    = "application/javascript; charset=utf-8"
    ".mjs"   = "application/javascript; charset=utf-8"
    ".css"   = "text/css; charset=utf-8"
    ".json"  = "application/json; charset=utf-8"
    ".png"   = "image/png"
    ".jpg"   = "image/jpeg"
    ".jpeg"  = "image/jpeg"
    ".gif"   = "image/gif"
    ".svg"   = "image/svg+xml"
    ".ico"   = "image/x-icon"
    ".woff"  = "font/woff"
    ".woff2" = "font/woff2"
    ".ttf"   = "font/ttf"
    ".txt"   = "text/plain; charset=utf-8"
}

function Send-HttpResponse($stream, [int]$statusCode, [string]$statusText, [string]$contentType, [byte[]]$bodyBytes) {
    $header = "HTTP/1.1 $statusCode $statusText`r`n" +
              "Content-Type: $contentType`r`n" +
              "Content-Length: $($bodyBytes.Length)`r`n" +
              "Access-Control-Allow-Origin: *`r`n" +
              "Access-Control-Allow-Methods: GET, POST, OPTIONS`r`n" +
              "Access-Control-Allow-Headers: Content-Type, Authorization`r`n" +
              "Cache-Control: no-cache`r`n" +
              "Connection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($bodyBytes.Length -gt 0) {
        $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    }
    $stream.Flush()
}

while ($true) {
    try {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $stream.ReadTimeout = 5000
        $stream.WriteTimeout = 5000

        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)
        $requestLine = $reader.ReadLine()
        if ([string]::IsNullOrEmpty($requestLine)) {
            $client.Close()
            continue
        }

        # Consume remaining HTTP headers
        while ($true) {
            $line = $reader.ReadLine()
            if ([string]::IsNullOrEmpty($line)) { break }
        }

        $parts = $requestLine.Split(' ')
        $method = if ($parts.Length -ge 1) { $parts[0] } else { "GET" }
        $rawUrl = if ($parts.Length -ge 2) { $parts[1].Split('?')[0] } else { "/" }
        $rawUrl = [System.Uri]::UnescapeDataString($rawUrl)

        if ($method -eq "OPTIONS") {
            Send-HttpResponse $stream 200 "OK" "text/plain" ([byte[]]::new(0))
            $client.Close()
            continue
        }

        if ($rawUrl -eq "/api/health") {
            $json = '{"status":"ok","version":"4.1.1","edition":"PK_OFFICIAL_DESKTOP","offline":true}'
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" ([System.Text.Encoding]::UTF8.GetBytes($json))
            $client.Close()
            continue
        }

        if ($rawUrl -eq "/api/auth/session" -or $rawUrl -eq "/api/auth/logout") {
            $json = '{"status":"ok","authenticated":true}'
            Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" ([System.Text.Encoding]::UTF8.GetBytes($json))
            $client.Close()
            continue
        }

        $relPath = $rawUrl.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
        $filePath = if ([string]::IsNullOrEmpty($relPath)) { Join-Path $Root "index.html" } else { Join-Path $Root $relPath }

        if (Test-Path $filePath -PathType Container) {
            $filePath = Join-Path $filePath "index.html"
        }

        if (-not (Test-Path $filePath -PathType Leaf)) {
            if (-not $rawUrl.StartsWith("/assets/")) {
                $filePath = Join-Path $Root "index.html"
            }
        }

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            Send-HttpResponse $stream 200 "OK" $mime $bytes
        } else {
            $notFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            Send-HttpResponse $stream 404 "Not Found" "text/plain; charset=utf-8" $notFound
        }

        $client.Close()
    } catch {
        try { if ($null -ne $client) { $client.Close() } } catch {}
    }
}
