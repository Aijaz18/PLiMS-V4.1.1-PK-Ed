# ===============================================================================
#   PLiMS V4.1.1 PK EDITION - STANDALONE WINDOWS OFFLINE HTTP ENGINE
#   Government of Pakistan - Department of Libraries & Academic ICT
#   Runs on Windows 7 SP1, 8, 8.1, 10, 11, Server 2012+ without Node.js or admin rights!
# ===============================================================================
param(
    [int]$Port = 3000,
    [string]$Root = (Join-Path $PSScriptRoot "dist")
)

$ErrorActionPreference = "SilentlyContinue"

# Check if port 3000 is already active
try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $tcp.Connect("127.0.0.1", $Port)
    $tcp.Close()
    Write-Host "[OK] PLiMS service is already running on port $Port."
    Exit 0
} catch {
    # Port is free, start local listener
}

$listener = New-Object System.Net.HttpListener
$prefix = "http://127.0.0.1:$Port/"
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    $Port = 8080
    $prefix = "http://127.0.0.1:$Port/"
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add($prefix)
    $listener.Start()
}

Write-Host "==============================================================================="
Write-Host "  PLiMS V4.1.1 PK EDITION - LOCAL DESKTOP SERVER ACTIVE"
Write-Host "  Listening on: $prefix"
Write-Host "  Serving: $Root"
Write-Host "==============================================================================="

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".mjs"  = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".gif"  = "image/gif"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".woff" = "font/woff"
    ".woff2"= "font/woff2"
    ".ttf"  = "font/ttf"
    ".txt"  = "text/plain; charset=utf-8"
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $rawUrl = $request.RawUrl.Split('?')[0]

        # API Endpoints for offline status
        if ($rawUrl -eq "/api/health") {
            $json = '{"status":"ok","version":"4.1.1","edition":"PK_OFFICIAL_DESKTOP","offline":true}'
            $buf = [System.Text.Encoding]::UTF8.GetBytes($json)
            $response.ContentType = "application/json"
            $response.ContentLength64 = $buf.Length
            $response.OutputStream.Write($buf, 0, $buf.Length)
            $response.OutputStream.Close()
            continue
        }

        # Resolve Static File
        $filePath = Join-Path $Root ($rawUrl.TrimStart('/'))
        if ($rawUrl -eq "/" -or (Test-Path $filePath -PathType Container)) {
            $filePath = Join-Path $Root "index.html"
        }

        # SPA Routing Fallback: if asset not found and not in /assets/, serve index.html
        if (-not (Test-Path $filePath -PathType Leaf)) {
            if (-not $rawUrl.StartsWith("/assets/")) {
                $filePath = Join-Path $Root "index.html"
            }
        }

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = "application/octet-stream"
            if ($mimeTypes.ContainsKey($ext)) { $mime = $mimeTypes[$ext] }

            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentType = $mime
            $response.ContentLength64 = $bytes.Length
            $response.AddHeader("Access-Control-Allow-Origin", "*")
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.OutputStream.Close()
        } else {
            $response.StatusCode = 404
            $msg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.OutputStream.Write($msg, 0, $msg.Length)
            $response.OutputStream.Close()
        }
    } catch {
        # Continue loop on connection reset
    }
}
