@echo off
title PLiMS V4.1.1 - Uninstall
echo ===============================================================================
echo   PLiMS V4.1.1 PK Edition - Uninstall Utility
echo ===============================================================================
echo.
set /p "CONFIRM=Are you sure you want to remove PLiMS 4.1.1 shortcuts from this computer? (Y/N): "
if /i not "%CONFIRM%"=="Y" exit /b 0

echo [*] Removing Desktop and Start Menu shortcuts...
del "%USERPROFILE%\Desktop\PLiMS 4.1.1 PK Edition.lnk" 2>nul
rmdir /S /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PLiMS 4.1.1" 2>nul

echo [*] PLiMS shortcuts removed.
echo [i] Application files are preserved in: "%~dp0"
echo [i] You can safely delete that folder if you wish to remove all files.
echo.
pause
