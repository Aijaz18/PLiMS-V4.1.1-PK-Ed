@echo off
title PLiMS V4.1.1 - Uninstall
del "%USERPROFILE%\Desktop\PLiMS 4.1.1 PK Edition.lnk" 2>nul
rmdir /S /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PLiMS 4.1.1" 2>nul
echo [OK] PLiMS 4.1.1 shortcuts removed.
pause
