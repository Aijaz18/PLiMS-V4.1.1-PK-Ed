@echo off
title PLiMS V4.1.1 - Uninstall
echo ===============================================================================
echo   PLiMS V4.1.1 PK Edition - Uninstall Utility
echo ===============================================================================
echo.
set /p "CONFIRM=Are you sure you want to remove PLiMS 4.1.1 shortcuts from this computer? (Y/N): "
if /i not "%CONFIRM%"=="Y" exit /b 0

echo [*] Stopping running PLiMS server if active...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*server.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

echo [*] Removing Desktop and Start Menu shortcuts...
del "%USERPROFILE%\Desktop\PLiMS 4.1.1 PK Edition.lnk" 2>nul
rmdir /S /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PLiMS 4.1.1" 2>nul

echo [*] PLiMS shortcuts removed.
pause
