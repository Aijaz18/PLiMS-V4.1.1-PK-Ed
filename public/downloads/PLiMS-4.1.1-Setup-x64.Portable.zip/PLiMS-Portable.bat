@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - USB Portable Mode
echo ===============================================================================
echo   PLiMS V4.1.1 PK EDITION - ZERO-INSTALL USB PORTABLE RUNNER
echo   Running directly from USB flash drive / local folder
echo ===============================================================================
echo.
cd /d "%~dp0"

set "PLIMS_DATA_DIR=%~dp0data"
set "PLIMS_PORTABLE=1"

echo [*] Starting local background web engine and opening PLiMS window...
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1" -LaunchBrowser

echo.
echo [OK] Portable PLiMS is active. Your browser/app window is opening now.
timeout /t 4 >nul
exit /b 0
