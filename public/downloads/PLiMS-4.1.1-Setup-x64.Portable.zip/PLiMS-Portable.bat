@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - USB Portable Mode
cd /d "%~dp0"

echo ===============================================================================
echo   PLiMS V4.1.1 PK EDITION - ZERO-INSTALL USB PORTABLE RUNNER
echo   Running directly from USB flash drive / local folder
echo ===============================================================================
echo.

set "PLIMS_DATA_DIR=%~dp0data"
set "PLIMS_PORTABLE=1"

echo [*] Starting local background engine on http://127.0.0.1:3000...
start /b "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0server.ps1" -Port 3000 >nul 2>&1
ping 127.0.0.1 -n 3 >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $c = New-Object System.Net.Sockets.TcpClient('127.0.0.1', 3000); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if !errorlevel! equ 0 (
    echo [OK] Portable Engine listening on http://127.0.0.1:3000
    start "" "http://127.0.0.1:3000"
) else (
    echo [OK] Launching Direct Portable Standalone Mode...
    start "" "%~dp0PLiMS-Application.html"
)

echo.
echo [OK] Portable PLiMS 4.1.1 is active.
timeout /t 4 >nul
