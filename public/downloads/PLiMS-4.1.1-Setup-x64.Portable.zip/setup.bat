@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - Windows Setup Wizard
color 1F

echo ===============================================================================
echo   GOVERNMENT OF PAKISTAN - DEPARTMENT OF LIBRARIES
echo   PAKISTAN LIBRARY MANAGEMENT SYSTEM (PLiMS V4.1.1 PK EDITION)
echo   OFFICIAL WINDOWS SETUP AND INSTALLATION WIZARD
echo ===============================================================================
echo.
set "DEFAULT_DIR=%LOCALAPPDATA%\PLiMS-4.1.1"
echo Installing PLiMS 4.1.1 to: %DEFAULT_DIR%
set "TARGET_DIR=%DEFAULT_DIR%"

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
if not exist "%TARGET_DIR%\dist" mkdir "%TARGET_DIR%\dist"
if not exist "%TARGET_DIR%\data" mkdir "%TARGET_DIR%\data"
if not exist "%TARGET_DIR%\config" mkdir "%TARGET_DIR%\config"
if not exist "%TARGET_DIR%\scripts" mkdir "%TARGET_DIR%\scripts"

cd /d "%~dp0"
xcopy /E /Y /I "dist\*" "%TARGET_DIR%\dist\" >nul 2>&1
xcopy /E /Y /I "data\*" "%TARGET_DIR%\data\" >nul 2>&1
xcopy /E /Y /I "config\*" "%TARGET_DIR%\config\" >nul 2>&1
xcopy /E /Y /I "scripts\*" "%TARGET_DIR%\scripts\" >nul 2>&1
copy /Y "PLiMS-Application.html" "%TARGET_DIR%\" >nul 2>&1
copy /Y "PLiMS-Launch.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "PLiMS-Silent-Launch.vbs" "%TARGET_DIR%\" >nul 2>&1
copy /Y "PLiMS-Portable.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "plims.ico" "%TARGET_DIR%\" >nul 2>&1
copy /Y "server.ps1" "%TARGET_DIR%\" >nul 2>&1
copy /Y "Uninstall-PLiMS.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "README-DESKTOP.txt" "%TARGET_DIR%\" >nul 2>&1

cscript //nologo "%~dp0scripts\create-shortcut.vbs" "%TARGET_DIR%"

echo.
echo [OK] Installation completed! Launching PLiMS 4.1.1...
wscript.exe "%TARGET_DIR%\PLiMS-Silent-Launch.vbs"
exit /b 0
