@echo off
setlocal enabledelayedexpansion
title PLiMS V4.1.1 PK Edition - Windows Setup Wizard
color 1F

echo ===============================================================================
echo   GOVERNMENT OF PAKISTAN - DEPARTMENT OF LIBRARIES
echo   PAKISTAN LIBRARY MANAGEMENT SYSTEM (PLiMS V4.1.1 PK EDITION)
echo   OFFICIAL WINDOWS SETUP AND INSTALLATION WIZARD
echo ===============================================================================
echo.
echo Welcome to the official PLiMS 4.1.1 Desktop Installation Wizard.
echo This wizard installs the full PLiMS suite on your Windows computer.
echo.
echo Complete Modules Included:
echo  [+] AI MARC21 / RDA Cataloguer and Dewey Decimal Classification
echo  [+] Circulation Desk (Issue, Return, Renew, Overdue Fines)
echo  [+] 24/7 AI Librarian Bot with Natural Language Library Queries
echo  [+] OPAC Online Public Access Catalog with Multi-Filter Search
echo  [+] Barcode Scanner and ESC/POS Thermal Receipt Printer Support
echo  [+] Localhost Database Engine (100% Offline No-Internet Operation)
echo  [+] Multi-Branch Campus Synchronization and Backup Service
echo.

set "DEFAULT_DIR=%LOCALAPPDATA%\PLiMS-4.1.1"
echo Default Installation Folder: %DEFAULT_DIR%
echo.
set /p "TARGET_DIR=Press ENTER to install in default folder, or enter custom path: "
if "%TARGET_DIR%"=="" set "TARGET_DIR=%DEFAULT_DIR%"

echo.
echo [*] Target Directory: "%TARGET_DIR%"
echo [*] Creating target folders...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
if not exist "%TARGET_DIR%\dist" mkdir "%TARGET_DIR%\dist"
if not exist "%TARGET_DIR%\data" mkdir "%TARGET_DIR%\data"
if not exist "%TARGET_DIR%\config" mkdir "%TARGET_DIR%\config"
if not exist "%TARGET_DIR%\scripts" mkdir "%TARGET_DIR%\scripts"

echo [*] Copying PLiMS 4.1.1 application modules and assets...
cd /d "%~dp0"
xcopy /E /Y /I "dist\*" "%TARGET_DIR%\dist\" >nul 2>&1
xcopy /E /Y /I "data\*" "%TARGET_DIR%\data\" >nul 2>&1
xcopy /E /Y /I "config\*" "%TARGET_DIR%\config\" >nul 2>&1
xcopy /E /Y /I "scripts\*" "%TARGET_DIR%\scripts\" >nul 2>&1
copy /Y "PLiMS-Launch.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "PLiMS-Portable.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "PLiMS.hta" "%TARGET_DIR%\" >nul 2>&1
copy /Y "server.ps1" "%TARGET_DIR%\" >nul 2>&1
copy /Y "Uninstall-PLiMS.bat" "%TARGET_DIR%\" >nul 2>&1
copy /Y "README-DESKTOP.txt" "%TARGET_DIR%\" >nul 2>&1

echo [*] Generating Windows Desktop and Start Menu shortcuts...
cscript //nologo "%~dp0scripts\create-shortcut.vbs" "%TARGET_DIR%"

echo.
echo ===============================================================================
echo   INSTALLATION COMPLETED SUCCESSFULLY!
echo ===============================================================================
echo   PLiMS 4.1.1 is now installed in: "%TARGET_DIR%"
echo   A desktop shortcut "PLiMS 4.1.1 PK Edition" has been created.
echo.
set /p "LAUNCH_NOW=Would you like to launch PLiMS 4.1.1 now? (Y/N) [Y]: "
if /i "%LAUNCH_NOW%"=="N" goto END
start "" "%TARGET_DIR%\PLiMS-Launch.bat"

:END
echo Exiting installer. Thank you for choosing PLiMS!
timeout /t 3 >nul
exit /b 0
