================================================================================
  PLiMS V4.1.1 PK EDITION (R2) - OFFICIAL WINDOWS DESKTOP PACKAGE
  Department of Libraries, Government of Pakistan
================================================================================

HOW TO LAUNCH AFTER INSTALLATION:
- Double-click "PLiMS 4.1.1 PK Edition" on your Windows Desktop, OR
- Run "PLiMS.exe" or "PLiMS-Launch.bat" inside %LOCALAPPDATA%\PLiMS-4.1.1

WHAT WAS FIXED IN REVISION 2 (R2):
1. Native PLiMS.exe Launcher & Icon (plims.ico):
   - Clicking "Finish" at the end of the installer or double-clicking the Desktop
     shortcut now executes the native PLiMS.exe binary with zero console flash.
2. Zero-Admin Winsock TcpListener Server Engine (server.ps1):
   - Replaced System.Net.HttpListener (which Windows 10/11 blocks with Error 5
     "Access is denied" without Administrator URL ACLs) with user-mode Winsock
     System.Net.Sockets.TcpListener.
   - Automatically finds a free port (3000, 3001, 8080) and opens PLiMS in a
     native standalone Edge/Chrome App window!
================================================================================
