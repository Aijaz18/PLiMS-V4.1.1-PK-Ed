================================================================================
  PLiMS V4.1.1 PK EDITION - OFFICIAL WINDOWS DESKTOP PACKAGE
  Department of Libraries, Government of Pakistan
================================================================================

HOW TO RUN AFTER INSTALLATION:
1. Double-click the "PLiMS 4.1.1 PK Edition" icon on your Windows Desktop or Start Menu.
2. Or open your installation folder (%LOCALAPPDATA%\PLiMS-4.1.1) and double-click:
   - PLiMS-Application.html (Instant Zero-Server Standalone Application)
   - PLiMS-Launch.bat (Local TCP Server Engine on http://127.0.0.1:3000)

ALL MODULES INCLUDED & ENABLED OFFLINE:
- Cataloguing (MARC21 / RDA / Dewey Decimal Classification)
- Circulation Desk (Issue, Return, Renew, Overdue Fines, Thermal Receipts)
- OPAC Public Catalog Discovery
- 24/7 AI Librarian Bot
- Barcode & QR Spine Label Generator
- Reports, Stock Verification, Serials, Authority Control & User Management
================================================================================
