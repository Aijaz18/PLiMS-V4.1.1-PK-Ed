================================================================================
  PLiMS V4.1.1 PK EDITION - OFFICIAL WINDOWS DESKTOP PACKAGE
  Department of Libraries, Government of Pakistan
================================================================================

PACKAGE DETAILS:
- Version: 4.1.1
- Release Date: October 2026
- Digital Authority: PLiMS Consortium & NLP Academic ICT Directorate

WHAT IS INCLUDED:
1. Complete Compiled Application Suite (dist/)
   - All modules: Cataloguing, Circulation, OPAC, AI Librarian Bot, Reports,
     Barcode Generator, Authority Control, Backup, Settings, User Management.
2. Built-in Local Offline Server Engine (server.ps1)
   - Operates 100% offline without continuous internet access.
   - Requires zero third-party software or pre-installed runtimes.
3. Windows Setup Wizard (setup.bat)
   - Installs to %LOCALAPPDATA%\PLiMS-4.1.1 or custom location.
   - Creates Desktop & Start Menu shortcuts automatically.
4. USB Portable Runner (PLiMS-Portable.bat)
   - Zero-installation mode for flash drives.
5. Hardware Peripheral Drivers
   - ESC/POS thermal slip receipt printers (58mm / 80mm).
   - USB Barcode scanners & RFID gate reader protocols.

SYSTEM REQUIREMENTS:
- Windows 11, Windows 10, Windows 8.1, Windows 7 SP1, or Windows Server 2012+
- 2 GB RAM (4 GB recommended)
- 500 MB free disk space

SUPPORT:
National Library of Pakistan ICT Directorate
Website: https://plims.gov.pk
Helpline: ahmedaniaijazakhter@gmail.com
================================================================================
