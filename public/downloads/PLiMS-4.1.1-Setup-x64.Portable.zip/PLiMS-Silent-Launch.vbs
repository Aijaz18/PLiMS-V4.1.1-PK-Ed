' PLiMS V4.1.1 Silent Desktop Application Launcher
Set oShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strDir = fso.GetParentFolderName(WScript.ScriptFullName)
oShell.CurrentDirectory = strDir

' 1. Start local unprivileged TCP HTTP server in hidden window
oShell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & strDir & "\server.ps1"" -Port 3000", 0, False

' 2. Wait 1.5 seconds for socket binding
WScript.Sleep 1500

' 3. Check if port 3000 is listening; if so open http://127.0.0.1:3000, otherwise open standalone HTML bundle
ret = oShell.Run("powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""try { $c = New-Object System.Net.Sockets.TcpClient('127.0.0.1', 3000); $c.Close(); exit 0 } catch { exit 1 }""", 0, True)
If ret = 0 Then
    oShell.Run "http://127.0.0.1:3000", 1, False
Else
    oShell.Run """" & strDir & "\PLiMS-Application.html""", 1, False
End If
